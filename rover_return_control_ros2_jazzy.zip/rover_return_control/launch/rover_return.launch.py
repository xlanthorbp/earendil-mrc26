from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os


def generate_launch_description():
    package_share = get_package_share_directory("rover_return_control")
    config_file = os.path.join(package_share, "config", "rover_params.yaml")

    motor_port = LaunchConfiguration("motor_port")
    heading_port = LaunchConfiguration("heading_port")

    return LaunchDescription(
        [
            DeclareLaunchArgument("motor_port", default_value="/dev/ttyACM0"),
            DeclareLaunchArgument("heading_port", default_value="/dev/ttyUSB0"),
            Node(
                package="rover_return_control",
                executable="motor_serial_node",
                name="motor_serial_node",
                output="screen",
                parameters=[config_file, {"serial_port": motor_port}],
            ),
            Node(
                package="rover_return_control",
                executable="heading_serial_node",
                name="heading_serial_node",
                output="screen",
                parameters=[config_file, {"serial_port": heading_port}],
            ),
            Node(
                package="rover_return_control",
                executable="return_controller_node",
                name="return_controller_node",
                output="screen",
                parameters=[config_file],
            ),
        ]
    )

