# Rover Return Control — ROS 2 Jazzy

Bu paket Arduino Mega üzerindeki BTS7960 motor kodunu değiştirmeden kullanır.
Arduino UNO'dan düzeltilmiş heading verisini okur, aracı WASD ile sürer ve
hareket komutlarının sürelerini kaydeder. `R` tuşunda rover önce manyetometreyle
180° döner, sonra kayıtlı segmentleri sondan başa oynatır.

## Geri dönüş eşlemesi

| Gidişte kaydedilen | 180° dönüşten sonra |
|---|---|
| `FWD` | `FWD` |
| `BACK` | `BACK` |
| `LEFT` | `RIGHT` |
| `RIGHT` | `LEFT` |

`STOP` süreleri rotaya eklenmez. Aynı komuta art arda basılması yeni segment
oluşturmaz; komut değişene kadar geçen gerçek süre kaydedilir.

## Düğümler

- `motor_serial_node`: `/dev/ttyACM0` portunun tek sahibidir. Mega'nın 750 ms
  watchdog'u düşmesin diye son güvenli komutu 10 Hz tekrarlar.
- `heading_serial_node`: `/dev/ttyUSB0` üzerinden UNO'yu okur ve
  `/compass/heading_deg` yayınlar.
- `return_controller_node`: kayıt, 180° kapalı çevrim dönüş ve ters rota durum
  makinesidir.
- `keyboard_teleop`: gerçek terminalden tuşları ve güvenlik heartbeat'ini
  yayınlar. Bilerek launch dosyasının içine konmamıştır.

## Raspberry Pi 5 kurulumu

```bash
sudo apt update
sudo apt install -y python3-serial python3-pytest

mkdir -p ~/arc26_ros2_ws/src
cd ~/arc26_ros2_ws/src
# ZIP'i bu klasöre çıkar; sonuç şu olmalı:
# ~/arc26_ros2_ws/src/rover_return_control/package.xml

cd ~/arc26_ros2_ws
source /opt/ros/jazzy/setup.bash
rosdep install --from-paths src --ignore-src -r -y
colcon build --packages-select rover_return_control --symlink-install
source install/setup.bash
```

Seri port izni bir kez verilmelidir:

```bash
sudo usermod -aG dialout $USER
```

Bu komuttan sonra oturumu kapatıp yeniden aç. Portları kontrol et:

```bash
ls -l /dev/ttyACM0 /dev/ttyUSB0
```

## Çalıştırma

Birinci terminal:

```bash
source /opt/ros/jazzy/setup.bash
source ~/arc26_ros2_ws/install/setup.bash
ros2 launch rover_return_control rover_return.launch.py
```

İkinci, klavye odağı olan terminal:

```bash
source /opt/ros/jazzy/setup.bash
source ~/arc26_ros2_ws/install/setup.bash
ros2 run rover_return_control keyboard_teleop
```

Tuşlar kilitli çalışır:

- `W`: ileri 80
- `S`: geri 80
- `A`: sola tank dönüşü 60
- `D`: sağa tank dönüşü 60
- `SPACE`: dur
- `R`: kaydı kapat, mevcut heading'in 180° tersine dön, rotayı geri oyna
- `E`: acil duruş ve otomatik geri dönüşü iptal
- `C`: eski kaydı temizle ve yeni kayıt başlat
- `Q`: dur ve klavye düğümünden çık

`keyboard_teleop` kapatılırsa ya da bağlantısı bir saniye kesilirse kontrolcü
motorları durdurur. Otomatik geri dönüşte de bu heartbeat zorunludur.

## İlk tekerler havadayken test

```bash
ros2 topic echo /compass/heading_deg
ros2 topic echo /rover/motor_command
ros2 topic echo /rover/return_status
ros2 topic echo /rover/motor_serial_rx
```

Önce heading'in aracı saat yönünde çevirdiğinde arttığını doğrula. Ters yönde
artıyorsa `config/rover_params.yaml` içinde:

```yaml
heading_increases_clockwise: false
```

yapıp paketi yeniden derle. Port adları farklıysa launch argümanlarıyla ver:

```bash
ros2 launch rover_return_control rover_return.launch.py \
  motor_port:=/dev/ttyACM1 heading_port:=/dev/ttyUSB1
```

Serial Monitor, `miniterm` veya başka bir program aynı portları açık tutmamalı.

## UNO seri çıktı şartı

Okuyucu aşağıdaki biçimlerden birini kabul eder:

```text
123.45
HEADING:123.45
HEADING,123.45
HDG=123.45
```

Yüklenen UNO metni `correctFinalHeading()` fonksiyonunun ortasında kesildiği
için onun gerçek `setup()`, `loop()` ve `Serial.print()` satırları görülemedi.
UNO'nun her geçerli ölçümde yukarıdaki biçimlerden biriyle, tercihen
`HEADING:123.45` basması gerekir.

## Fiziksel doğruluk sınırı

180° dönüş manyetometre geri beslemelidir. Fakat sonrasındaki rota, yalnız motor
komutu ve sürelerini ters oynatır; teker enkoderi veya konum geri beslemesi
yoktur. Skid-steer kayması, zemin eğimi, akü gerilimi ve motor farkları nedeniyle
rover başlangıç noktasına yaklaşık döner; santimetre hassasiyet garanti edilmez.
Son rota ayrıca `~/.ros/rover_return/last_route.json` dosyasına yazılır.

