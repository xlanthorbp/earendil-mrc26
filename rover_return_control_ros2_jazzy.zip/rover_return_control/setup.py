from glob import glob
import os
from setuptools import find_packages, setup


package_name = "rover_return_control"

setup(
    name=package_name,
    version="1.0.0",
    packages=find_packages(exclude=["test"]),
    data_files=[
        ("share/ament_index/resource_index/packages", ["resource/" + package_name]),
        ("share/" + package_name, ["package.xml", "README.md"]),
        (os.path.join("share", package_name, "launch"), glob("launch/*.launch.py")),
        (os.path.join("share", package_name, "config"), glob("config/*.yaml")),
    ],
    install_requires=["setuptools", "pyserial"],
    zip_safe=True,
    maintainer="Earendil Rover Team",
    maintainer_email="earendil@example.com",
    description="WASD teleoperation and compass-assisted recorded path return",
    license="MIT",
    entry_points={
        "console_scripts": [
            "motor_serial_node = rover_return_control.motor_serial_node:main",
            "heading_serial_node = rover_return_control.heading_serial_node:main",
            "return_controller_node = rover_return_control.return_controller_node:main",
            "keyboard_teleop = rover_return_control.keyboard_teleop:main",
        ],
    },
)
