import math

import pytest

from rover_return_control.heading_parser import parse_heading_line
from rover_return_control.route_logic import (
    circular_mean_deg,
    invert_for_return,
    shortest_angular_error,
    valid_motor_command,
)


@pytest.mark.parametrize(
    ("original", "expected"),
    [
        ("MOTOR:FWD:80", "MOTOR:FWD:80"),
        ("MOTOR:BACK:80", "MOTOR:BACK:80"),
        ("MOTOR:LEFT:60", "MOTOR:RIGHT:60"),
        ("MOTOR:RIGHT:60", "MOTOR:LEFT:60"),
        ("MOTOR:STOP", "MOTOR:STOP"),
    ],
)
def test_return_mapping(original, expected):
    assert invert_for_return(original) == expected


def test_commands_are_strictly_validated():
    assert valid_motor_command("MOTOR:FWD:255")
    assert not valid_motor_command("MOTOR:FWD:256")
    assert not valid_motor_command("MOTOR:FWD:-1")
    assert not valid_motor_command("garbage")


@pytest.mark.parametrize(
    ("target", "current", "expected"),
    [(10, 350, 20), (350, 10, -20), (180, 0, -180), (91, 90, 1)],
)
def test_shortest_error(target, current, expected):
    assert shortest_angular_error(target, current) == pytest.approx(expected)


def test_circular_mean_handles_north_wrap():
    mean = circular_mean_deg([359.0, 0.0, 1.0])
    assert min(abs(mean), abs(mean - 360.0)) < 0.01


@pytest.mark.parametrize(
    ("line", "expected"),
    [
        ("123.4", 123.4),
        ("HEADING: 42.5", 42.5),
        ("HEADING,359.0", 359.0),
        ("HDG = 361", 1.0),
        ("# QMC yeniden baslatiliyor", None),
        ("valid=4500 failed=2", None),
    ],
)
def test_heading_parser(line, expected):
    actual = parse_heading_line(line)
    if expected is None:
        assert actual is None
    else:
        assert math.isclose(actual, expected)

