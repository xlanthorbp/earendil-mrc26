from __future__ import annotations

from dataclasses import asdict, dataclass
import math
import re
from typing import Iterable


COMMAND_RE = re.compile(r"^MOTOR:(FWD|BACK|LEFT|RIGHT):(\d{1,3})$")
STOP_COMMAND = "MOTOR:STOP"


@dataclass(frozen=True)
class RecordedSegment:
    command: str
    duration_s: float

    def to_dict(self) -> dict:
        data = asdict(self)
        data["return_command"] = invert_for_return(self.command)
        return data


def valid_motor_command(command: str) -> bool:
    if command == STOP_COMMAND:
        return True
    match = COMMAND_RE.fullmatch(command)
    return bool(match and 0 <= int(match.group(2)) <= 255)


def invert_for_return(command: str) -> str:
    """Map a command after the rover has physically turned 180 degrees."""
    if command == STOP_COMMAND:
        return command
    match = COMMAND_RE.fullmatch(command)
    if not match:
        raise ValueError(f"Invalid motor command: {command}")
    direction, pwm = match.groups()
    inverse_direction = {
        "FWD": "FWD",
        "BACK": "BACK",
        "LEFT": "RIGHT",
        "RIGHT": "LEFT",
    }[direction]
    return f"MOTOR:{inverse_direction}:{pwm}"


def normalize_heading(angle_deg: float) -> float:
    return angle_deg % 360.0


def shortest_angular_error(target_deg: float, current_deg: float) -> float:
    """Return signed target-current error in [-180, 180)."""
    return (target_deg - current_deg + 180.0) % 360.0 - 180.0


def circular_mean_deg(headings_deg: Iterable[float]) -> float:
    headings = list(headings_deg)
    if not headings:
        raise ValueError("At least one heading is required")
    sin_sum = sum(math.sin(math.radians(value)) for value in headings)
    cos_sum = sum(math.cos(math.radians(value)) for value in headings)
    return normalize_heading(math.degrees(math.atan2(sin_sum, cos_sum)))

