from __future__ import annotations

import time

import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from std_msgs.msg import Bool, Float64

import serial
from serial import SerialException

from .heading_parser import parse_heading_line


class HeadingSerialNode(Node):
    def __init__(self) -> None:
        super().__init__("heading_serial_node")
        self.declare_parameter("serial_port", "/dev/ttyUSB0")
        self.declare_parameter("baud_rate", 115200)
        self.declare_parameter("poll_rate_hz", 50.0)
        self.declare_parameter("reconnect_interval_s", 2.0)

        self.port = str(self.get_parameter("serial_port").value)
        self.baud = int(self.get_parameter("baud_rate").value)
        poll_rate = float(self.get_parameter("poll_rate_hz").value)
        self.reconnect_interval = float(
            self.get_parameter("reconnect_interval_s").value
        )

        self.serial_device: serial.Serial | None = None
        self.last_connect_attempt = 0.0
        self.rx_buffer = bytearray()

        self.heading_pub = self.create_publisher(
            Float64, "/compass/heading_deg", qos_profile_sensor_data
        )
        self.connected_pub = self.create_publisher(
            Bool, "/compass/serial_connected", 1
        )
        self.timer = self.create_timer(1.0 / max(poll_rate, 5.0), self.tick)
        self.get_logger().info(
            f"UNO heading reader starting on {self.port} at {self.baud} baud"
        )

    def publish_connected(self, connected: bool) -> None:
        msg = Bool()
        msg.data = connected
        self.connected_pub.publish(msg)

    def connect(self) -> None:
        now = time.monotonic()
        if now - self.last_connect_attempt < self.reconnect_interval:
            return
        self.last_connect_attempt = now
        try:
            self.serial_device = serial.Serial(
                self.port,
                self.baud,
                timeout=0,
                exclusive=True,
            )
            self.rx_buffer.clear()
            self.publish_connected(True)
            self.get_logger().info("UNO heading serial connection established")
        except (SerialException, OSError) as exc:
            self.serial_device = None
            self.publish_connected(False)
            self.get_logger().warning(f"Cannot open {self.port}: {exc}")

    def disconnect(self, reason: Exception | str) -> None:
        if self.serial_device is not None:
            try:
                self.serial_device.close()
            except (SerialException, OSError):
                pass
        self.serial_device = None
        self.publish_connected(False)
        self.get_logger().error(f"UNO serial disconnected: {reason}")

    def process_line(self, raw_line: bytes) -> None:
        line = raw_line.decode("utf-8", errors="replace").strip()
        heading = parse_heading_line(line)
        if heading is None:
            if line and not line.startswith("#"):
                self.get_logger().debug(f"Ignored UNO line: {line}")
            return
        msg = Float64()
        msg.data = heading
        self.heading_pub.publish(msg)

    def tick(self) -> None:
        if self.serial_device is None or not self.serial_device.is_open:
            self.connect()
            return
        try:
            waiting = self.serial_device.in_waiting
            if waiting:
                self.rx_buffer.extend(self.serial_device.read(min(waiting, 4096)))
            if len(self.rx_buffer) > 8192:
                self.rx_buffer = self.rx_buffer[-4096:]
            while b"\n" in self.rx_buffer:
                raw_line, _, remainder = self.rx_buffer.partition(b"\n")
                self.rx_buffer = bytearray(remainder)
                self.process_line(raw_line)
        except (SerialException, OSError) as exc:
            self.disconnect(exc)

    def destroy_node(self) -> bool:
        if self.serial_device is not None:
            try:
                self.serial_device.close()
            except (SerialException, OSError):
                pass
        return super().destroy_node()


def main(args=None) -> None:
    rclpy.init(args=args)
    node = HeadingSerialNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

