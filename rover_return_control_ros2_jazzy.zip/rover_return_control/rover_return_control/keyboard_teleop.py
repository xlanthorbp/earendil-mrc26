from __future__ import annotations

import select
import sys
import termios
import tty

import rclpy
from rclpy.node import Node
from std_msgs.msg import Empty, String


HELP = """
Earendil Rover klavye kontrolu

  W : ileri (PWM 80)       S : geri (PWM 80)
  A : sola don (PWM 60)    D : saga don (PWM 60)
  SPACE : dur              R : 180 derece don ve rotayi geri oyna
  E : acil durus           C : kaydi temizle / yeni rota
  Q : motoru durdur ve klavye dugumunden cik

Komutlar kilitlidir: W'ye bir kez basinca SPACE veya baska komuta kadar ilerler.
Geri donus sirasinda SPACE, E veya Q islemi derhal iptal eder.
"""


class KeyboardTeleop(Node):
    def __init__(self) -> None:
        super().__init__("keyboard_teleop")
        self.key_pub = self.create_publisher(String, "/rover/teleop_key", 20)
        self.heartbeat_pub = self.create_publisher(
            Empty, "/rover/teleop_heartbeat", 10
        )
        self.create_timer(0.2, self.publish_heartbeat)

    def publish_heartbeat(self) -> None:
        self.heartbeat_pub.publish(Empty())

    def publish_key(self, key: str) -> None:
        msg = String()
        msg.data = key
        self.key_pub.publish(msg)


def main(args=None) -> None:
    if not sys.stdin.isatty():
        print("HATA: keyboard_teleop gercek bir terminalde calistirilmalidir.")
        print("Ikinci terminalde: ros2 run rover_return_control keyboard_teleop")
        return

    rclpy.init(args=args)
    node = KeyboardTeleop()
    original_settings = termios.tcgetattr(sys.stdin)
    print(HELP, flush=True)

    try:
        tty.setcbreak(sys.stdin.fileno())
        running = True
        while rclpy.ok() and running:
            rclpy.spin_once(node, timeout_sec=0.05)
            readable, _, _ = select.select([sys.stdin], [], [], 0.0)
            if not readable:
                continue
            key = sys.stdin.read(1).lower()
            if key in ("w", "a", "s", "d", "r", "e", "c", "q", " "):
                node.publish_key(key)
                if key == "q":
                    running = False
    except KeyboardInterrupt:
        node.publish_key("e")
    finally:
        node.publish_key(" ")
        for _ in range(3):
            rclpy.spin_once(node, timeout_sec=0.05)
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, original_settings)
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

