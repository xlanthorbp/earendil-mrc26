from __future__ import annotations

from collections import deque
from enum import Enum
import json
import os
import time

import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from std_msgs.msg import Empty, Float64, String

from .route_logic import (
    RecordedSegment,
    STOP_COMMAND,
    circular_mean_deg,
    invert_for_return,
    normalize_heading,
    shortest_angular_error,
)


class State(Enum):
    MANUAL = "MANUAL"
    PREPARING_TURN = "PREPARING_TURN"
    TURNING_180 = "TURNING_180"
    RETURN_PAUSE = "RETURN_PAUSE"
    REPLAYING = "REPLAYING"
    COMPLETE = "COMPLETE"
    ERROR = "ERROR"


class ReturnControllerNode(Node):
    def __init__(self) -> None:
        super().__init__("return_controller_node")

        self.declare_parameter("forward_pwm", 80)
        self.declare_parameter("reverse_pwm", 80)
        self.declare_parameter("manual_turn_pwm", 60)
        self.declare_parameter("auto_turn_pwm", 60)
        self.declare_parameter("heading_tolerance_deg", 7.5)
        self.declare_parameter("heading_timeout_s", 1.0)
        self.declare_parameter("teleop_heartbeat_timeout_s", 1.0)
        self.declare_parameter("turn_timeout_s", 20.0)
        self.declare_parameter("turn_initial_settle_s", 0.4)
        self.declare_parameter("turn_required_samples", 3)
        self.declare_parameter("post_turn_pause_s", 0.5)
        self.declare_parameter("minimum_segment_s", 0.08)
        self.declare_parameter("heading_increases_clockwise", True)
        self.declare_parameter(
            "route_log_path", "~/.ros/rover_return/last_route.json"
        )

        self.forward_pwm = int(self.get_parameter("forward_pwm").value)
        self.reverse_pwm = int(self.get_parameter("reverse_pwm").value)
        self.manual_turn_pwm = int(
            self.get_parameter("manual_turn_pwm").value
        )
        self.auto_turn_pwm = int(self.get_parameter("auto_turn_pwm").value)
        self.heading_tolerance = float(
            self.get_parameter("heading_tolerance_deg").value
        )
        self.heading_timeout = float(
            self.get_parameter("heading_timeout_s").value
        )
        self.heartbeat_timeout = float(
            self.get_parameter("teleop_heartbeat_timeout_s").value
        )
        self.turn_timeout = float(self.get_parameter("turn_timeout_s").value)
        self.turn_initial_settle = float(
            self.get_parameter("turn_initial_settle_s").value
        )
        self.turn_required_samples = int(
            self.get_parameter("turn_required_samples").value
        )
        self.post_turn_pause = float(
            self.get_parameter("post_turn_pause_s").value
        )
        self.minimum_segment = float(
            self.get_parameter("minimum_segment_s").value
        )
        self.heading_increases_clockwise = bool(
            self.get_parameter("heading_increases_clockwise").value
        )
        self.route_log_path = os.path.expanduser(
            str(self.get_parameter("route_log_path").value)
        )

        self.state = State.MANUAL
        self.route: list[RecordedSegment] = []
        self.current_manual_command = STOP_COMMAND
        self.segment_started_at = time.monotonic()
        self.output_command = ""

        self.last_heartbeat_at = 0.0
        self.last_heading_at = 0.0
        self.latest_heading: float | None = None
        self.heading_sequence = 0
        self.last_processed_heading_sequence = -1
        self.recent_headings: deque[tuple[float, float]] = deque(maxlen=10)

        self.target_heading = 0.0
        self.turn_started_at = 0.0
        self.turn_settle_until = 0.0
        self.heading_samples_in_tolerance = 0

        self.replay_segments: list[RecordedSegment] = []
        self.replay_index = 0
        self.replay_deadline = 0.0
        self.pause_deadline = 0.0

        self.command_pub = self.create_publisher(
            String, "/rover/motor_command", 20
        )
        self.status_pub = self.create_publisher(String, "/rover/return_status", 20)
        self.create_subscription(
            String, "/rover/teleop_key", self.key_callback, 20
        )
        self.create_subscription(
            Empty, "/rover/teleop_heartbeat", self.heartbeat_callback, 10
        )
        self.create_subscription(
            Float64,
            "/compass/heading_deg",
            self.heading_callback,
            qos_profile_sensor_data,
        )
        self.timer = self.create_timer(0.05, self.tick)

        self.set_output(STOP_COMMAND)
        self.publish_status("Hazir: WASD, SPACE=dur, R=geri donus, E=acil durus")

    def publish_status(self, detail: str) -> None:
        msg = String()
        msg.data = f"{self.state.value},{detail}"
        self.status_pub.publish(msg)
        self.get_logger().info(msg.data)

    def set_output(self, command: str) -> None:
        if command == self.output_command:
            return
        self.output_command = command
        msg = String()
        msg.data = command
        self.command_pub.publish(msg)

    def heartbeat_callback(self, _msg: Empty) -> None:
        self.last_heartbeat_at = time.monotonic()

    def heading_callback(self, msg: Float64) -> None:
        now = time.monotonic()
        heading = normalize_heading(float(msg.data))
        self.latest_heading = heading
        self.last_heading_at = now
        self.heading_sequence += 1
        self.recent_headings.append((now, heading))

    def close_current_segment(self, now: float) -> None:
        duration = max(0.0, now - self.segment_started_at)
        if (
            self.current_manual_command != STOP_COMMAND
            and duration >= self.minimum_segment
        ):
            self.route.append(
                RecordedSegment(self.current_manual_command, duration)
            )

    def change_manual_command(self, command: str) -> None:
        if command == self.current_manual_command:
            return
        now = time.monotonic()
        self.close_current_segment(now)
        self.current_manual_command = command
        self.segment_started_at = now
        self.set_output(command)

    def reset_recording(self) -> None:
        self.set_output(STOP_COMMAND)
        self.route.clear()
        self.current_manual_command = STOP_COMMAND
        self.segment_started_at = time.monotonic()
        self.state = State.MANUAL
        self.publish_status("Kayit temizlendi; yeni rota kaydi basladi")

    def abort(self, reason: str) -> None:
        self.set_output(STOP_COMMAND)
        self.current_manual_command = STOP_COMMAND
        self.segment_started_at = time.monotonic()
        self.state = State.ERROR
        self.publish_status(f"DURDURULDU: {reason}; C ile sifirla")

    def key_callback(self, msg: String) -> None:
        key = msg.data.lower()

        if key in ("e", "q", " ") and self.state not in (
            State.MANUAL,
            State.COMPLETE,
            State.ERROR,
        ):
            self.abort("operator acil durusu")
            return

        if key == "c":
            if self.state in (State.MANUAL, State.COMPLETE, State.ERROR):
                self.reset_recording()
            return

        if self.state != State.MANUAL:
            return

        commands = {
            "w": f"MOTOR:FWD:{self.forward_pwm}",
            "s": f"MOTOR:BACK:{self.reverse_pwm}",
            "a": f"MOTOR:LEFT:{self.manual_turn_pwm}",
            "d": f"MOTOR:RIGHT:{self.manual_turn_pwm}",
            " ": STOP_COMMAND,
            "e": STOP_COMMAND,
            "q": STOP_COMMAND,
        }
        if key in commands:
            self.change_manual_command(commands[key])
        elif key == "r":
            self.start_return()

    def start_return(self) -> None:
        now = time.monotonic()
        self.close_current_segment(now)
        self.current_manual_command = STOP_COMMAND
        self.segment_started_at = now
        self.set_output(STOP_COMMAND)

        if not self.route:
            self.state = State.MANUAL
            self.publish_status("Geri donus baslatilmadi: kayitli hareket yok")
            return
        if (
            self.latest_heading is None
            or now - self.last_heading_at > self.heading_timeout
        ):
            self.state = State.MANUAL
            self.publish_status("Geri donus baslatilmadi: guncel heading yok; tekrar R'ye bas")
            return

        self.turn_settle_until = now + self.turn_initial_settle
        self.heading_samples_in_tolerance = 0
        self.last_processed_heading_sequence = -1
        self.state = State.PREPARING_TURN
        self.publish_status(
            "Rover durduruldu; kesin baslangic heading'i olculuyor"
        )

    def begin_turn_after_settle(self, now: float) -> None:
        if (
            self.latest_heading is None
            or now - self.last_heading_at > self.heading_timeout
        ):
            self.abort("180 derece donus oncesi guncel heading alinamadi")
            return
        fresh = [
            heading
            for stamp, heading in self.recent_headings
            if now - stamp <= min(self.heading_timeout, 0.5)
        ]
        start_heading = circular_mean_deg(fresh or [self.latest_heading])
        self.target_heading = normalize_heading(start_heading + 180.0)
        self.turn_started_at = now
        self.heading_samples_in_tolerance = 0
        self.last_processed_heading_sequence = -1
        self.state = State.TURNING_180
        self.save_route_log(start_heading)
        self.publish_status(
            f"180 derece donus: baslangic={start_heading:.1f}, hedef={self.target_heading:.1f}"
        )

    def save_route_log(self, start_heading: float) -> None:
        payload = {
            "created_unix_s": time.time(),
            "start_of_turn_heading_deg": start_heading,
            "turn_target_heading_deg": self.target_heading,
            "segments": [segment.to_dict() for segment in self.route],
        }
        try:
            directory = os.path.dirname(self.route_log_path)
            if directory:
                os.makedirs(directory, exist_ok=True)
            with open(self.route_log_path, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, indent=2)
        except OSError as exc:
            self.get_logger().warning(f"Route log could not be written: {exc}")

    def heartbeat_is_fresh(self, now: float) -> bool:
        return now - self.last_heartbeat_at <= self.heartbeat_timeout

    def control_turn(self, now: float) -> None:
        if now - self.turn_started_at > self.turn_timeout:
            self.abort("180 derece donus zaman asimi")
            return
        if now - self.last_heading_at > self.heading_timeout:
            self.abort("manyetometre verisi zaman asimi")
            return
        assert self.latest_heading is not None
        error = shortest_angular_error(self.target_heading, self.latest_heading)
        is_new_sample = self.heading_sequence != self.last_processed_heading_sequence
        if is_new_sample:
            self.last_processed_heading_sequence = self.heading_sequence

        if abs(error) <= self.heading_tolerance:
            self.set_output(STOP_COMMAND)
            if is_new_sample:
                self.heading_samples_in_tolerance += 1
            if self.heading_samples_in_tolerance >= self.turn_required_samples:
                self.state = State.RETURN_PAUSE
                self.pause_deadline = now + self.post_turn_pause
                self.replay_segments = list(reversed(self.route))
                self.replay_index = 0
                self.publish_status(
                    f"180 derece tamamlandi: heading={self.latest_heading:.1f}; rota oynatilacak"
                )
            return

        self.heading_samples_in_tolerance = 0
        # Corrected compass headings normally increase clockwise. This is a
        # parameter because a physically mirrored sensor may do the opposite.
        turn_right = error > 0.0
        if not self.heading_increases_clockwise:
            turn_right = not turn_right
        direction = "RIGHT" if turn_right else "LEFT"
        self.set_output(f"MOTOR:{direction}:{self.auto_turn_pwm}")

    def start_replay_segment(self, now: float) -> None:
        if self.replay_index >= len(self.replay_segments):
            self.set_output(STOP_COMMAND)
            self.state = State.COMPLETE
            self.publish_status("Geri donus tamamlandi; C ile yeni rota baslat")
            return
        segment = self.replay_segments[self.replay_index]
        command = invert_for_return(segment.command)
        self.set_output(command)
        self.replay_deadline = now + segment.duration_s
        self.publish_status(
            f"Segment {self.replay_index + 1}/{len(self.replay_segments)}: "
            f"{command}, {segment.duration_s:.2f} s"
        )

    def tick(self) -> None:
        now = time.monotonic()

        if not self.heartbeat_is_fresh(now):
            if self.state in (
                State.PREPARING_TURN,
                State.TURNING_180,
                State.RETURN_PAUSE,
                State.REPLAYING,
            ):
                self.abort("klavye dugumu heartbeat kaybi")
            elif self.state == State.MANUAL and self.output_command != STOP_COMMAND:
                self.change_manual_command(STOP_COMMAND)
                self.publish_status("Klavye baglantisi kesildi; motorlar durduruldu")
            return

        if self.state == State.PREPARING_TURN:
            self.set_output(STOP_COMMAND)
            if now >= self.turn_settle_until:
                self.begin_turn_after_settle(now)
        elif self.state == State.TURNING_180:
            self.control_turn(now)
        elif self.state == State.RETURN_PAUSE:
            self.set_output(STOP_COMMAND)
            if now >= self.pause_deadline:
                self.state = State.REPLAYING
                self.start_replay_segment(now)
        elif self.state == State.REPLAYING:
            if now >= self.replay_deadline:
                self.replay_index += 1
                self.start_replay_segment(now)
        elif self.state in (State.COMPLETE, State.ERROR):
            self.set_output(STOP_COMMAND)

    def destroy_node(self) -> bool:
        self.set_output(STOP_COMMAND)
        return super().destroy_node()


def main(args=None) -> None:
    rclpy.init(args=args)
    node = ReturnControllerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
