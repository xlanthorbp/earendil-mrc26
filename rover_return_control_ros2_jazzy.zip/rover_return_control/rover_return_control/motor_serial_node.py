from __future__ import annotations

import time

import rclpy
from rclpy.node import Node
from std_msgs.msg import Bool, String

import serial
from serial import SerialException

from .route_logic import STOP_COMMAND, valid_motor_command


class MotorSerialNode(Node):
    """The only process that owns the Mega serial port and feeds its watchdog."""

    def __init__(self) -> None:
        super().__init__("motor_serial_node")
        self.declare_parameter("serial_port", "/dev/ttyACM0")
        self.declare_parameter("baud_rate", 115200)
        self.declare_parameter("send_rate_hz", 10.0)
        self.declare_parameter("reconnect_interval_s", 2.0)
        self.declare_parameter("arduino_reset_wait_s", 2.0)

        self.port = str(self.get_parameter("serial_port").value)
        self.baud = int(self.get_parameter("baud_rate").value)
        send_rate = float(self.get_parameter("send_rate_hz").value)
        self.reconnect_interval = float(
            self.get_parameter("reconnect_interval_s").value
        )
        self.reset_wait = float(self.get_parameter("arduino_reset_wait_s").value)

        self.serial_device: serial.Serial | None = None
        self.desired_command = STOP_COMMAND
        self.last_connect_attempt = 0.0
        self.rx_buffer = bytearray()

        self.ack_pub = self.create_publisher(String, "/rover/motor_serial_rx", 20)
        self.connected_pub = self.create_publisher(
            Bool, "/rover/motor_connected", 1
        )
        self.create_subscription(
            String, "/rover/motor_command", self.command_callback, 20
        )
        self.timer = self.create_timer(1.0 / max(send_rate, 2.0), self.tick)

        self.get_logger().info(
            f"Mega motor bridge starting on {self.port} at {self.baud} baud"
        )

    def command_callback(self, msg: String) -> None:
        command = msg.data.strip()
        if not valid_motor_command(command):
            self.get_logger().error(f"Rejected invalid command: {command!r}")
            self.desired_command = STOP_COMMAND
            return
        self.desired_command = command

    def publish_connected(self, connected: bool) -> None:
        msg = Bool()
        msg.data = connected
        self.connected_pub.publish(msg)

    def connect(self) -> None:
        now = time.monotonic()
        if now - self.last_connect_attempt < self.reconnect_interval:
            return
        self.last_connect_attempt = now
        try:
            self.serial_device = serial.Serial(
                self.port,
                self.baud,
                timeout=0,
                write_timeout=0.2,
                exclusive=True,
            )
            # Opening a Mega usually resets it. Never move during that interval.
            time.sleep(self.reset_wait)
            self.serial_device.reset_input_buffer()
            self.serial_device.write((STOP_COMMAND + "\n").encode("ascii"))
            self.publish_connected(True)
            self.get_logger().info("Mega motor serial connection established")
        except (SerialException, OSError) as exc:
            self.serial_device = None
            self.publish_connected(False)
            self.get_logger().warning(f"Cannot open {self.port}: {exc}")

    def disconnect(self, reason: Exception | str) -> None:
        if self.serial_device is not None:
            try:
                self.serial_device.close()
            except (SerialException, OSError):
                pass
        self.serial_device = None
        self.publish_connected(False)
        self.get_logger().error(f"Mega serial disconnected: {reason}")

    def read_available(self) -> None:
        assert self.serial_device is not None
        waiting = self.serial_device.in_waiting
        if waiting:
            self.rx_buffer.extend(self.serial_device.read(min(waiting, 4096)))
        if len(self.rx_buffer) > 8192:
            self.rx_buffer = self.rx_buffer[-4096:]
        while b"\n" in self.rx_buffer:
            raw_line, _, remainder = self.rx_buffer.partition(b"\n")
            self.rx_buffer = bytearray(remainder)
            line = raw_line.decode("utf-8", errors="replace").strip()
            if line:
                msg = String()
                msg.data = line
                self.ack_pub.publish(msg)

    def tick(self) -> None:
        if self.serial_device is None or not self.serial_device.is_open:
            self.connect()
            return
        try:
            self.serial_device.write((self.desired_command + "\n").encode("ascii"))
            self.read_available()
        except (SerialException, OSError) as exc:
            self.disconnect(exc)

    def stop_motors(self) -> None:
        if self.serial_device is None or not self.serial_device.is_open:
            return
        for _ in range(3):
            try:
                self.serial_device.write((STOP_COMMAND + "\n").encode("ascii"))
                time.sleep(0.03)
            except (SerialException, OSError):
                break

    def destroy_node(self) -> bool:
        self.stop_motors()
        if self.serial_device is not None:
            try:
                self.serial_device.close()
            except (SerialException, OSError):
                pass
        return super().destroy_node()


def main(args=None) -> None:
    rclpy.init(args=args)
    node = MotorSerialNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

