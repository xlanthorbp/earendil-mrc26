from __future__ import annotations

import re
from typing import Optional


NUMBER = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)"
LABELED_HEADING_RE = re.compile(
    rf"(?:^|[,;\s])(?:HEADING|HDG|YON)\s*[:=,;\s]\s*({NUMBER})(?:\s*(?:DEG|DERECE))?(?:$|[,;\s])",
    re.IGNORECASE,
)
BARE_HEADING_RE = re.compile(rf"^\s*({NUMBER})\s*$")


def parse_heading_line(line: str) -> Optional[float]:
    """Parse a heading without mistaking counters/status messages for data."""
    stripped = line.strip()
    if not stripped or stripped.startswith("#"):
        return None

    match = LABELED_HEADING_RE.search(stripped) or BARE_HEADING_RE.fullmatch(stripped)
    if not match:
        return None

    value = float(match.group(1))
    if not -360.0 <= value <= 720.0:
        return None
    return value % 360.0

