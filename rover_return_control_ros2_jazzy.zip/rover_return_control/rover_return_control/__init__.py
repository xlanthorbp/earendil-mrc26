"""ROS 2 rover teleoperation and recorded-path return package."""

